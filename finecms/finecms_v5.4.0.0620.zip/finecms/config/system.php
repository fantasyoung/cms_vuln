<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * FineCMS
 */

/**
 * 系统配置文件
 */

return array (
    'SYS_LOG' => 1,
    'SYS_KEY' => 'finecms5key',
    'SYS_DEBUG' => 0,
    'SYS_EMAIL' => 'cms@dayrui.ocm',
    'SYS_AUTO_CACHE' => 1,
    'SITE_ADMIN_CODE' => 0,
    'SITE_ADMIN_PAGESIZE' => '8',
    'SYS_CACHE_INDEX' => 3600,
    'SYS_CACHE_MSHOW' => 3600,
    'SYS_CACHE_MSEARCH' => 3600,
    'SYS_CACHE_LIST' => 3600,
    'SYS_CACHE_MEMBER' => 3600,
    'SYS_CACHE_ATTACH' => 3600,
    'SYS_CACHE_FORM' => 3600,
    'SYS_CACHE_TAG' => 3600,
    'SYS_CAT_MODULE' => 0,
    'SYS_HTTPS' => 0,
);