<?php

return array(

    'DR_UPDATE'		=> '2018.06.18',
    'DR_VERSION'	=> '5.4.0',
);
