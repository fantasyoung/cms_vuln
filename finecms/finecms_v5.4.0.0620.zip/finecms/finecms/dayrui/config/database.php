<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

require WEBPATH.'config/database.php';