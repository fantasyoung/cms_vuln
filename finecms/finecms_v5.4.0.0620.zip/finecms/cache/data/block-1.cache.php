a:3:{i:1;a:2:{i:1;s:18:"首页文本公告";i:0;s:172:"FineCMS公益版v5.0正式上线了，全新内容管理设计，灵活，高负载|#009688
FineCMS公益版永久免费开源，不计较版权，开源QQ群：8615168|red";}i:2;a:2:{i:1;s:18:"首页幻灯图片";i:0;s:170:"http://www.dayrui.com/static/assets/banner/finecms-1.jpg
http://www.dayrui.com/static/assets/banner/finecms-2.jpg
http://www.dayrui.com/static/assets/banner/finecms-3.jpg";}i:3;a:2:{i:1;s:12:"友情链接";i:0;s:79:"http://www.finecms.net|公益版论坛
http://www.dayrui.com|天睿程序设计";}}